## Prerequisites:

* zainstalowany golang na urządzeniu

## Instruction:

* wejsc w folder publish_app
* nastepnie w folderze publish_app uruchomic komende go mod download
* a na koniec uruchomić aplikacje poprzez komendę: go run sum.go
* tyle :)

